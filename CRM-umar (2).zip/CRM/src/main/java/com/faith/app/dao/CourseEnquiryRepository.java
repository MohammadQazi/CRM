package com.faith.app.dao;


	
import org.springframework.data.jpa.repository.JpaRepository;

import com.faith.app.dto.CourseEnquiryModel;

public interface CourseEnquiryRepository extends JpaRepository<CourseEnquiryModel, Long>{

}	


